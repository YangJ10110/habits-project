package com.jerome.habits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HabitsTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
